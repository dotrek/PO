package com.mygdx.game;

public class DodgeBallTeam extends Team {

	public DodgeBallTeam(String text) {
		super(text);
	}
}