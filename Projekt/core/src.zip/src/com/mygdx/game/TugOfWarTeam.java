package com.mygdx.game;

public class TugOfWarTeam extends Team {

	public TugOfWarTeam(String text) {
		super(text);
	}
}
