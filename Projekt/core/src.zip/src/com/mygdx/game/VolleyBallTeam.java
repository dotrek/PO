package com.mygdx.game;

public class VolleyBallTeam extends Team {

	public VolleyBallTeam(String text) {
		// TODO Auto-generated constructor stub
		super(text);
	}

}
