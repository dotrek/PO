package com.mygdx.game;

public class Referee {
	String name, surname;

	Referee(String namee, String surnamee) {
		name = namee;
		surname = surnamee;
	}

	public String getName() {
		return name;
	}

	public String getSurname() {
		return surname;
	}

}