package Exceptions;

public class SameNameException extends ProjectException {
	public SameNameException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
