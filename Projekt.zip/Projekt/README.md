# GameDevKiddies
Game dev science club of Technical University of Bialystok.
