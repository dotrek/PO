package Exceptions;

public class ProjectException extends Exception {
	public ProjectException() {

	}

	public ProjectException(String msg) {
		super(msg);
	}
}
