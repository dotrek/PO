package Exceptions;

public class NotEnoughSizeException extends ProjectException {

	public NotEnoughSizeException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
