package matches;

import java.util.ArrayList;

import com.mygdx.game.Referee;
import com.mygdx.game.Team;

public class DodgeBallGame extends Match {

	public DodgeBallGame(Team t1, Team t2, ArrayList<Referee> refik) {
		super(t1, t2, refik);
	}

}