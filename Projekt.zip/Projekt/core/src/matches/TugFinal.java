package matches;

import java.util.ArrayList;

import com.mygdx.game.Referee;
import com.mygdx.game.Team;

public class TugFinal extends TugOfWarGame {

	public TugFinal(Team t1, Team t2, ArrayList<Referee> refik) {
		super(t1, t2, refik);
		// TODO Auto-generated constructor stub
	}

}
